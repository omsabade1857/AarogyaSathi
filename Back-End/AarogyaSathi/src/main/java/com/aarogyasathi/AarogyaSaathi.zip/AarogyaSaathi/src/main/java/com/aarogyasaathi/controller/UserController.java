package com.aarogyasaathi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.aarogyasaathi.model.UserDetails;
import com.aarogyasaathi.service.UserService;
import com.aarogyasaathi.util.UserServiceException;


import com.aarogyasaathi.dto.LoginDetails;
import com.aarogyasaathi.dto.LoginStatus;
import com.aarogyasaathi.dto.NewPatient;
import com.aarogyasaathi.dto.RegistrationStatus;

@RestController
@CrossOrigin
public class UserController {

	@Autowired
	private UserService userService;
	
	@PostMapping("/signup")
	public ResponseEntity<RegistrationStatus> register(@RequestBody UserDetails user) {	
		
		try {
				
		int id=userService.addUser(user);
		RegistrationStatus reg=new RegistrationStatus();
		
		reg.setPatientId(id);
		reg.setStatus(true);
		reg.setMessage("Patient registered successfully !");

		return new ResponseEntity<RegistrationStatus>(reg, HttpStatus.OK);
		
		}
		catch(UserServiceException exc) {
			RegistrationStatus reg=new RegistrationStatus();
			
			reg.setStatus(false);
			reg.setMessage(exc.getMessage());
			
			return new ResponseEntity<RegistrationStatus>(reg, HttpStatus.BAD_REQUEST);
		}
	}
	
	 @PostMapping("/user/login")
		public ResponseEntity<?> login(@RequestBody LoginDetails loginDetails) {
			try {
				UserDetails user = userService.login(loginDetails.getEmail(), loginDetails.getPassword());
				LoginStatus status = new LoginStatus();
				status.setStatus(true);
				status.setMessage("Login successful!");
				status.setId (user.getUserId());
				status.setName(user.getName());
				return new ResponseEntity<LoginStatus>(status, HttpStatus.OK);
			}
			catch (UserServiceException e) {
				LoginStatus status = new LoginStatus();
				status.setStatus(false);
				status.setMessage(e.getMessage());

				return new ResponseEntity<LoginStatus>(status, HttpStatus.BAD_REQUEST);
			}
		}
}
