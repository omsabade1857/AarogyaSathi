package com.aarogyasaathi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aarogyasaathi.model.GenderDetails;
import com.aarogyasaathi.model.Roles;
import com.aarogyasaathi.model.SpecializationDetails;
import com.aarogyasaathi.model.UserDetails;
import com.aarogyasaathi.repository.GenderRepository;
import com.aarogyasaathi.repository.RolesRepository;
import com.aarogyasaathi.repository.SpecializationRepository;
import com.aarogyasaathi.repository.UserRepository;
import com.aarogyasaathi.util.UserServiceException;


@Service
public class UserService {

		@Autowired
		private UserRepository userRepo;
		@Autowired
		private GenderRepository genderRepo;
		@Autowired
		private RolesRepository rolesRepo; 	
		@Autowired
		private SpecializationRepository specRepo;
		
		public int addUser(UserDetails user) throws UserServiceException{
			
			Optional<UserDetails> checkUser=userRepo.findByEmail(user.getEmail());
			 	List<GenderDetails> genderList = genderRepo.findByGender(user.getGender().getGender());
			    if (genderList.isEmpty()) {
			        throw new IllegalArgumentException("Invalid gender");
			    }
			    GenderDetails gender = genderList.get(0);
			    user.setGender(gender);
			    			  
			    List<Roles> roleList = rolesRepo.findByRoleType(user.getRole().getRoleType());
			    if (roleList.isEmpty()) {
			        throw new IllegalArgumentException("Invalid role");
			    }
			    Roles role = roleList.get(0);
			    user.setRole(role);
			
				 List<SpecializationDetails> specList = specRepo.findBySpecialization(user.getSpecialization().getSpecialization());
				    if (specList.isEmpty()) {
				        throw new IllegalArgumentException("Invalid specialization");
				    }
				    SpecializationDetails spec = specList.get(0);
				    user.setSpecialization(spec);

			if(checkUser.isEmpty()) {
				UserDetails savedUser=userRepo.save(user);
				return savedUser.getUserId();
			}
			else{
				throw new UserServiceException("Patient with this email is already registered ");
			}	
		}


		public UserDetails login(String email, String password) throws UserServiceException{
			
				Optional<UserDetails> user = userRepo.findByEmailAndPassword(email, password);
				if(user.isPresent())
					return user.get();
				else
					throw new UserServiceException("Invalid Email/Password");
			} 
		}
		

