package com.aarogyasaathi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aarogyasaathi.model.UserDetails;


public interface UserRepository extends JpaRepository<UserDetails, Integer>{

		public Optional<UserDetails> findByEmail(String email);
		
		public Optional<UserDetails> findByEmailAndPassword(String email, String password);
}
