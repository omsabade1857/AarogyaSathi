package com.aarogyasaathi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aarogyasaathi.model.Roles;
import com.aarogyasaathi.model.Roles.RoleType;

public interface RolesRepository extends JpaRepository<Roles, Integer>{
	public List<Roles> findByRoleType(RoleType role);
	
}
