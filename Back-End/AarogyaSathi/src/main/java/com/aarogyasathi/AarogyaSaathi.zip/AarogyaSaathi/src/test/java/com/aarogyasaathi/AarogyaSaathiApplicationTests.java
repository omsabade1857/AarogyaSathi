package com.aarogyasaathi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AarogyaSaathiApplicationTests {

	@Test
	void contextLoads() {
	}

}
