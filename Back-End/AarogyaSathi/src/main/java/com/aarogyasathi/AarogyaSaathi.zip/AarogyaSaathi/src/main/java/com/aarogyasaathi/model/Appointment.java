package com.aarogyasaathi.model;

import java.time.LocalDate;
import java.time.LocalTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;


	@Entity
	@Table(name="as_appointment")
	@Getter
	@Setter
	public class Appointment {

		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		private int appId;
		private LocalDate visitDate;
		private LocalTime time;
		
		@ManyToOne
		@JoinColumn(name = "statusId")
		private AppointmentStatus status;
		
	
		@ManyToOne
		@JoinColumn(name = "patientId")
		private UserDetails patient;
		
	
		@ManyToOne
		@JoinColumn(name = "doctorId")
		private UserDetails doctor;
			
	}
