package com.aarogyasaathi.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aarogyasaathi.model.GenderDetails;
import com.aarogyasaathi.model.GenderDetails.Gender;
import com.aarogyasaathi.model.UserDetails;

public interface GenderRepository extends JpaRepository<GenderDetails, Integer>{
	public List<GenderDetails> findByGender(Gender gender);
	
}
