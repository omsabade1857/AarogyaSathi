package com.aarogyasaathi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AarogyaSaathiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AarogyaSaathiApplication.class, args);
	}

}
