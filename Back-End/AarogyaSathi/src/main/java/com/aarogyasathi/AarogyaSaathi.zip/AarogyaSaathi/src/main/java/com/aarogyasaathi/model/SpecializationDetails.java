package com.aarogyasaathi.model;

import java.util.List;

import com.aarogyasaathi.model.GenderDetails.Gender;
import com.aarogyasaathi.model.Roles.RoleType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="as_specialization_details")
public class SpecializationDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int specializationId;

	@Enumerated(EnumType.STRING)
	@Column(unique = true)
	private Specialization specialization;
	
	public enum Specialization{
		GENERAL_MEDICINE, CARDIOLOGY, OPHTHALMOLOGY, DERMATOLOGY, ORTHOPEDICS ;
	}
	
	@OneToMany(mappedBy ="specialization")
	private List<UserDetails> users;

	public int getSpecializationId() {
		return specializationId;
	}

	public void setSpecializationId(int specializationId) {
		this.specializationId = specializationId;
	}

	public Specialization getSpecialization() {
		return specialization;
	}

	public void setSpecialization(Specialization specialization) {
		this.specialization = specialization;
	}

	public List<UserDetails> getUsers() {
		return users;
	}

	public void setUsers(List<UserDetails> users) {
		this.users = users;
	}
	
	
}
