package com.aarogyasaathi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aarogyasaathi.model.SpecializationDetails;
import com.aarogyasaathi.model.SpecializationDetails.Specialization;

public interface SpecializationRepository extends JpaRepository<SpecializationDetails, Integer> {
	public List<SpecializationDetails> findBySpecialization(Specialization specialization);
}
