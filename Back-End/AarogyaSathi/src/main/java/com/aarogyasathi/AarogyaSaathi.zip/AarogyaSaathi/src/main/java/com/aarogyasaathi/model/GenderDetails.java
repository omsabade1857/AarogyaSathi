package com.aarogyasaathi.model;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="as_gender_details")
public class GenderDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int genderId;
	
	@Enumerated(EnumType.STRING)
	@Column(unique = true)
	private Gender gender;
	
	public enum Gender{
		MALE, FEMALE;
	}
	
	@OneToMany(mappedBy ="gender")
	private List<UserDetails> users;

	public int getGenderId() {
		return genderId;
	}

	public void setGenderId(int genderId) {
		this.genderId = genderId;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public List<UserDetails> getUsers() {
		return users;
	}

	public void setUsers(List<UserDetails> users) {
		this.users = users;
	}

	@Override
	public String toString() {
		return "GenderDetails [genderId=" + genderId + ", gender=" + gender + ", users=" + users + "]";
	}

	

}

