
package com.aarogyasaathi.model;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

	@Entity
	@Table(name = "as_patient_history")
	@Getter
	@Setter
	public class PatientHistory {

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int recordId;
		private LocalDate visitDate;
		private String symptoms;
		private String suggestion;
		
		@ManyToOne
		@JoinColumn(name = "userId")
		private UserDetails user;

		@OneToMany(mappedBy ="medicineId")
		private List<Medicine> medicines;
		
	}

